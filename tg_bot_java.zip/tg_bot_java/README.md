# NIE_Lab3_Java
# Creating Telegram Bot

![Screenshot](Screenshot_1.jpg)
![Screenshot](Screenshot_2.jpg)
